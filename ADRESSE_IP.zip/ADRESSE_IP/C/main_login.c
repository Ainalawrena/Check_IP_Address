#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ip_login.h"

int main()
{   
    choix();
    return 0;
}